module.exports = {
  mode: "production",
  devtool: "source-map",
};
