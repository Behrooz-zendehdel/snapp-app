import React from "react";
import Layout from "../Layout/Layout";

const Bike = () => {
  return <Layout></Layout>;
};

export default Bike;
