import React from "react";
import Layout from "../Layout/Layout";

const Food = () => {
  return <Layout></Layout>;
};

export default Food;
