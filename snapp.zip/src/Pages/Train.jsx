import React from "react";
import Layout from "../Layout/Layout";

const Train = () => {
  return <Layout></Layout>;
};

export default Train;
