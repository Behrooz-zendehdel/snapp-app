import React from "react";
import Layout from "../Layout/Layout";

const Doctor = () => {
  return <Layout></Layout>;
};

export default Doctor;
