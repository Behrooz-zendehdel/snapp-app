import React from "react";
import Layout from "../Layout/Layout";

const Club = () => {
  return <Layout></Layout>;
};

export default Club;
