import React from "react";
import Layout from "../Layout/Layout";
const Jobs = () => {
  return (
    <Layout>
      <h2>this is jobs</h2>
    </Layout>
  );
};

export default Jobs;
