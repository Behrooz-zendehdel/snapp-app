import React from "react";
import Layout from "../Layout/Layout";

const Bus = () => {
  return <Layout></Layout>;
};

export default Bus;
