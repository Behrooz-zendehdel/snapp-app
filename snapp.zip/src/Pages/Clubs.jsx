import React from "react";
import Layout from "../Layout/Layout";

const Clubs = () => {
  return (
    <Layout>
      <h2>this is  clubs</h2>
    </Layout>
  );
};

export default Clubs;
