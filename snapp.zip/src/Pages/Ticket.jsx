import React from "react";
import Layout from "../Layout/Layout";

const Ticket = () => {
  return <Layout></Layout>;
};

export default Ticket;
