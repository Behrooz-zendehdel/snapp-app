import React from "react";
import Layout from "../Layout/Layout";

const Organization = () => {
  return (
    <Layout>
      <h2>this is organizition</h2>
    </Layout>
  );
};

export default Organization;
