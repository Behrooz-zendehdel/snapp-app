import React from "react";
import Layout from "../Layout/Layout";

const Pay = () => {
  return <Layout></Layout>;
};

export default Pay;
