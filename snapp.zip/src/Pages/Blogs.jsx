import React from "react";
import Layout from "../Layout/Layout";

const Blogs = () => {
  return (
    <Layout>
      <h2>this is blogs</h2>
    </Layout>
  );
};

export default Blogs;
