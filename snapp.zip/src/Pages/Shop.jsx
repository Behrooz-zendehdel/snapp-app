import React from "react";
import Layout from "../Layout/Layout";

const Shop = () => {
  return <Layout></Layout>;
};

export default Shop;
